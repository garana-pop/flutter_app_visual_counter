package net.garana.flutter_app_visual_counter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
